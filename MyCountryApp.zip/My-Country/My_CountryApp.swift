//
//  My_CountryApp.swift
//  My-Country
//
//  Created by Abdirahman Standard on 14/10/24.
//

import SwiftUI

@main
struct My_CountryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
